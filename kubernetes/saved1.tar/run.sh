kubectl create -f ./engine-deployment.yaml
kubectl create -f ./engine-service.yaml
kubectl create -f ./aiplayer-deployment.yaml
kubectl create -f ./aiplayer-service.yaml
kubectl create -f ./dashboard-deployment.yaml
kubectl create -f ./dashboard-service.yaml
