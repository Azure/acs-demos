kubectl delete service engine
kubectl delete service aiplayer
kubectl delete service dashboard

kubectl delete deployment engine
kubectl delete deployment aiplayer
kubectl delete deployment dashboard
